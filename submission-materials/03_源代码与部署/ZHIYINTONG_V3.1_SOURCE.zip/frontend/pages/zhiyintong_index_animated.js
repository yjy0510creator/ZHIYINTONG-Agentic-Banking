export { default } from "./index";
